package com.dicoding.android_arka

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAboutActivity: Button = findViewById(R.id.btn_about)
        btnAboutActivity.setOnClickListener(this)

        val btnGoogle: Button = findViewById(R.id.btn_google,)
        btnGoogle.setOnClickListener(this)

        val btnIg: Button = findViewById(R.id.btn_ig,)
        btnIg.setOnClickListener(this)

        val btnNetflix: Button = findViewById(R.id.btn_netflix,)
        btnNetflix.setOnClickListener(this)

        val btnPs: Button = findViewById(R.id.btn_ps,)
        btnPs.setOnClickListener(this)

        val btnShopee: Button = findViewById(R.id.btn_shopee,)
        btnShopee.setOnClickListener(this)

        val btnSpotify: Button = findViewById(R.id.btn_spotify,)
        btnSpotify.setOnClickListener(this)

        val btnTiktok: Button = findViewById(R.id.btn_tiktok,)
        btnTiktok.setOnClickListener(this)

        val btnTwt: Button = findViewById(R.id.btn_twt,)
        btnTwt.setOnClickListener(this)

        val btnWa: Button = findViewById(R.id.btn_wa,)
        btnWa.setOnClickListener(this)

        val btnYt: Button = findViewById(R.id.btn_yt,)
        btnYt.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_about -> {
                val moveIntent = Intent(this@MainActivity, AboutActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_google -> {
                val moveIntent = Intent(this@MainActivity, GoogleActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_ig -> {
                val moveIntent = Intent(this@MainActivity, IgActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_netflix -> {
                val moveIntent = Intent(this@MainActivity, NetflixActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_ps -> {
                val moveIntent = Intent(this@MainActivity, PsActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_shopee -> {
                val moveIntent = Intent(this@MainActivity, ShopeeActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_spotify -> {
                val moveIntent = Intent(this@MainActivity, SpotifyActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_tiktok -> {
                val moveIntent = Intent(this@MainActivity, TiktokActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_twt -> {
                val moveIntent = Intent(this@MainActivity, TwtActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_wa -> {
                val moveIntent = Intent(this@MainActivity, WaActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_yt -> {
                val moveIntent = Intent(this@MainActivity, YtActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}
